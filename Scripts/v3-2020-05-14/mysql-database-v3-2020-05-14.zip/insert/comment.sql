insert into tbl_comment values('chilkyustar',1,'��!');
insert into tbl_comment values('louis',2,'good!');
