INSERT INTO `comma`.`tbl_heart`
(`h_id`,
`m_id`,
`s_id`)
VALUES(
1,
'louis',
'1');

INSERT INTO `comma`.`tbl_heart`
(`h_id`,
`m_id`,
`s_id`)
VALUES(
3,
'chilkyustar',
'2');
