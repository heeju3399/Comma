-- > member
  -- > insert
	INSERT INTO `comma`.`tbl_member` (`m_id`, `m_pwd`, `m_name`, `m_email`, `m_birth`, `m_visited`, `m_auth`)
	VALUES ('root', 1234, 'admin','neat-white-tree@naver.com', '1989-02-22',now(),'admin');
	INSERT INTO `comma`.`tbl_member` (`m_id`, `m_pwd`, `m_name`, `m_email`, `m_birth`, `m_visited`, `m_auth`)
	VALUES ('louis', 1234, 'louisevil','louis.develog@gmail.com', '1989-03-21',now(),'user');
	INSERT INTO `comma`.`tbl_member` (`m_id`, `m_pwd`, `m_name`, `m_email`, `m_birth`, `m_visited`, `m_auth`)
	VALUES ('chilkyustar', 1234, '7q','chilkyu.star@gmail.com', '1989-01-21',now(),'user');
  -- < insert
-- < member









