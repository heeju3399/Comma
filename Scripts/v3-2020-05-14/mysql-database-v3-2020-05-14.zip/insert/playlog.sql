SELECT * FROM comma.tbl_playlog;

INSERT INTO `comma`.`tbl_playlog`
(`p_id`,
`m_id`,
`p_time`,
`s_id`)
VALUES(
1,
'chilkyustar',
now(),
1);

INSERT INTO `comma`.`tbl_playlog`
(`p_id`,
`m_id`,
`p_time`,
`s_id`)
VALUES(
2,
'chilkyustar',
now(),
2);