SELECT * FROM comma.tbl_rating;
insert into tbl_rating(m_id,s_id,r_id,r_score) values ('louis',1,1,5);
insert into tbl_rating(m_id,s_id,r_id,r_score) values ('louis',2,2,4);
insert into tbl_rating(m_id,s_id,r_id,r_score) values ('chilkyustar',1,3,5);
insert into tbl_rating(m_id,s_id,r_id,r_score) values ('root',2,4,4);