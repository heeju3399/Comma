SELECT * FROM comma.tbl_tag;
insert into tbl_tag(t_id,t_name,s_id,m_id) values(1,'국가스텐',1,'louis');
insert into tbl_tag(t_id,t_name,s_id,m_id) values(2,'하현우',1,'louis');
